## Pantheon Tean Software to analyse and picture clouds in ISS
## using the AstroPi Project
##
## This is the part of the Pantheon Team Software
## to be run in the ISS
## A second part is done to finish analyses of pictures 
## on earth after the ISS mission and make 3D pictures from
## gathered pictures. 
##
## Last modification date: 22.2.22 22:22
## The Pantheon Team is lead by Serge Smidtas, and Anna and Eva Corot
## contact:  s@sergi5.com

## Tu use the max resolution of camera 
## (4056, 3040) pixels insted of (3432, 2574)
## We modified: 
## sed -i "s/^gpu_mem=.*/gpu_mem=256/" /boot/config.txt
## as it is configured also in ISS

## Used libraries (as existing in the ISS)
from pathlib import Path
from logzero import logger, logfile
from picamera import PiCamera
from orbit import ISS
from skyfield.api import load
from time import sleep
from datetime import datetime, timedelta
import csv

## Functions usefull provided by AstroPi team with minor modifications

def create_csv_file(data_file):
    #Create a new CSV file and add the header row
    with open(data_file, 'w') as f:
        writer = csv.writer(f)
        header = ("Counter", "Date/time", "Latitude", "Longitude")
        writer.writerow(header)

def add_csv_data(data_file, data):
    #Add a row of data to the data_file CSV
    with open(data_file, 'a') as f:
        writer = csv.writer(f)
        writer.writerow(data)

def convert(angle):
    """
    Convert a `skyfield` Angle to an EXIF-appropriate
    representation (rationals)
    e.g. 98° 34' 58.7 to "98/1,34/1,587/10"

    Return a tuple containing a boolean and the converted angle,
    with the boolean indicating if the angle is negative.
    """
    sign, degrees, minutes, seconds = angle.signed_dms()
    exif_angle = f'{degrees:.0f}/1,{minutes:.0f}/1,{seconds*10:.0f}/10'
    return sign < 0, exif_angle

def capture(camera, image):
    #Use `camera` to capture an `image` file with lat/long EXIF data.
    location = ISS.coordinates()

    # Convert the latitude and longitude to EXIF-appropriate representations
    south, exif_latitude = convert(location.latitude)
    west, exif_longitude = convert(location.longitude)

    # Set the EXIF tags specifying the current location
    camera.exif_tags['GPS.GPSLatitude'] = exif_latitude
    camera.exif_tags['GPS.GPSLatitudeRef'] = "S" if south else "N"
    camera.exif_tags['GPS.GPSLongitude'] = exif_longitude
    camera.exif_tags['GPS.GPSLongitudeRef'] = "W" if west else "E"

    # Capture the image
    camera.capture(image)

## No absolute path is allowed. Use of the __file__ parameter
base_folder = Path(__file__).parent.resolve()

# Localiser jour/nuit
# Requires internet only the first time to get the file, 
# But now the file is provided in this project
ephemeride = load('de421.bsp')
timescale = load.timescale()

# Set a logfile name
logfile(base_folder/"events.log")

# Set up camera
cam = PiCamera()
cam.resolution = (4056, 3040) #Objectif flickr = best resolution
#cam.resolution = (1296, 972) #Data AstroPi
#cam.resolution = (3432, 2574) #works without increasing memory 

# Initialise the CSV file
data_file = base_folder/"data.csv"
create_csv_file(data_file)

# Initialise the photo counter
counter = 1

# Time between pictures is very important to make 3D stereoscopic images 
# as some times some solar panel and othe stuff can be in front of the camera
# and the speed/altiture of ISS may vary a little various (3)
# delays are used between pictures and this is a compromize
# between the 3D effect and the size of earth covered by the 3D picture
# Theses values have been tested using the first set of pictures
# taken in january by AstroPi provided in Flicker

# List times possible between 2 photos
tempus = [18, 20, 23]

# Record the start and current time
start_time = datetime.now()
now_time = datetime.now()
# Run a loop for (almost) three hours4056
while (now_time < start_time + timedelta(minutes=178)):
    try:
        # List times possible between 2 photos
        t=timescale.now()
        if ISS.at(t).is_sunlit(ephemeride):
            #logger.info("Jour") #=day
            soleil = "day"
            tempus = [18, 20, 23] #time in seconds between pictures
        else:
            # during night we take less pictures to optimize disk space usage
            #logger.info("Nuit") # =night
            soleil = "nuit"
            tempus = [18, 23, 120] #time in seconds between pictures
        # Get coordinates of location on Earth below the ISS
        location = ISS.coordinates()
        # Save the data to the file
        data = (
            counter,
            datetime.now(),
            location.latitude.degrees,
            location.longitude.degrees,
        )
        add_csv_data(data_file, data)
        # Capture image
        image_file = f"{base_folder}/pictures/photo_{counter:03d}.jpg"
        capture(cam, image_file)

        # Log event
        
        logger.info(f"iteration {counter}" + f" tempus: {tempus[counter%3]}" + f" soleil: {soleil}" + f" latitude: {location.latitude.degrees}" + f" longitude: {location.longitude.degrees}")
        counter += 1
        sleep(tempus[counter%3])
        # Update the current time
        now_time = datetime.now()
    except Exception as e:
        logger.error(f'{e.__class__.__name__}: {e}')
